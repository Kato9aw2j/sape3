// SAPE móvil: Resistencia de Aislamiento en cuatro pasos.
"use strict";

const CLAVE_ESTADO = "sape-movil-estado";
const CLAVE_HISTORIAL = "sape-movil-historial";

const estado = {
  vista: "inicio", // inicio | ra | historial
  paso: 1,
  modo: "mide",
  datos: {
    equipo: "2d", configuracion: "Trifásico", fase: "A", terciario: "con",
    secciones: "varias", tempAmbiente: "", humedad: "", tempDevanado: "",
    aislamiento: "aceite",
  },
  prueba: 0,
  lecturas: { r30: "", r1: "", r10: "" },
  resultado: null,
};

function leer(clave, respaldo) {
  try {
    const crudo = localStorage.getItem(clave);
    return crudo ? JSON.parse(crudo) : respaldo;
  } catch (_e) {
    return respaldo;
  }
}

function guardar(clave, valor) {
  try {
    localStorage.setItem(clave, JSON.stringify(valor));
  } catch (_e) {
    // Sin almacenamiento (modo privado): la app sigue funcionando.
  }
}

function recordar() {
  guardar(CLAVE_ESTADO, {
    datos: estado.datos, prueba: estado.prueba, lecturas: estado.lecturas,
  });
}

const previo = leer(CLAVE_ESTADO, null);
if (previo && previo.datos) {
  Object.assign(estado.datos, previo.datos);
  estado.prueba = previo.prueba || 0;
  Object.assign(estado.lecturas, previo.lecturas || {});
}

const esc = (texto) =>
  String(texto).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function formatoKv(valor) {
  const partes = String(valor).replace("/", "-").split("-");
  const nums = partes.map((parte) => Number(parte));
  if (nums.some((n) => !Number.isFinite(n))) return String(valor);
  return nums.map((n) => String(n / 1000)).join(" - ") + " kV";
}

function pruebaActual() {
  const lista = pruebasDe(estado.datos);
  if (estado.prueba >= lista.length) estado.prueba = 0;
  return lista[estado.prueba];
}

const MENU = [
  ["1", "Resistencia de Aislamiento", "R.A.Ω", "ra"],
  ["2", "Factor de Potencia al Aislamiento", "%F.P.", null],
  ["3", "Relación de Transformación", "T.T.R.", null],
  ["4", "Corriente de Excitación", "I.EXC", null],
  ["5", "Resistencia Óhmica de Devanados", "R.O.Ω", null],
  ["6", "Normativa y Procedimientos", "CFE-IEEE", null],
  ["7", "Historial de Análisis", "", "historial"],
];

function vistaInicio() {
  const filas = MENU.map(([num, nombre, marca, destino]) => `
    <button class="menu-item" ${destino ? `data-ir="${destino}"` : "disabled"}>
      <span>${num}. ${esc(nombre)}</span>
      <span class="marca">${destino ? (marca ? `[ ${esc(marca)} ]` : "›") : "Próximamente"}</span>
    </button>`).join("");
  return `
    <main class="inicio">
      <div class="logo-cfe">CFE</div>
      <p class="org">COMISIÓN FEDERAL DE ELECTRICIDAD<br>ZONA DE TRANSMISIÓN JALISCO ORIENTE<br>SUBESTACIONES</p>
      <h1 class="logo-sape">[ S.A.P.E. ]</h1>
      <p class="sub">SISTEMA DE ANÁLISIS DE PRUEBAS ELÉCTRICAS<br>VERSIÓN MÓVIL 1.0</p>
      <nav class="menu">${filas}</nav>
      <p class="pie">Procedimiento ST-CT-001 · Funciona sin conexión</p>
    </main>`;
}

const PASOS = ["Datos del equipo", "Selección de pruebas", "Diagramas de bloques", "Captura de lecturas"];

function barraPasos() {
  return `<ol class="pasos">${PASOS.map((nombre, i) => `
    <li><button data-paso="${i + 1}" class="${estado.paso === i + 1 ? "activo" : ""}" aria-label="${esc(nombre)}">
      <b>0${i + 1}</b></button></li>`).join("")}</ol>`;
}

function campo(etiqueta, clave, extra) {
  return `<label class="campo"><span>${esc(etiqueta)}</span>
    <input inputmode="decimal" data-dato="${clave}" value="${esc(estado.datos[clave])}" ${extra || ""}></label>`;
}

function opciones(clave, pares, bloqueada) {
  return `<div class="segmentos">${pares.map(([valor, texto]) => `
    <button data-dato="${clave}" data-valor="${valor}"
      class="${estado.datos[clave] === valor ? "activo" : ""}"
      ${bloqueada === valor ? "disabled" : ""}>${esc(texto)}</button>`).join("")}</div>`;
}

function paso1() {
  const d = estado.datos;
  const solido = soloSolido(d.equipo);
  if (solido) d.aislamiento = "seco";
  const instrumento = ["tc", "tp", "tpc"].includes(d.equipo);
  let extra = "";
  if (instrumento) {
    extra = `<div class="campo"><span>Fase</span>${opciones("fase", [["A", "A"], ["B", "B"], ["C", "C"]])}</div>`;
  } else {
    extra = `<div class="campo"><span>Configuración</span>${opciones("configuracion", [["Trifásico", "Trifásico"], ["Monofásico", "Monofásico"]])}</div>`;
  }
  if (d.equipo === "apart") {
    extra += `<div class="campo"><span>Configuración del apartarrayos</span>${opciones("secciones", [["una", "Una sección"], ["varias", "Varias secciones"]])}</div>`;
  }
  if (d.equipo === "auto") {
    extra += `<div class="campo"><span>Devanado terciario</span>${opciones("terciario", [["con", "Con terciario"], ["sin", "Sin terciario"]])}</div>`;
  }
  return `
    <h2>01. Datos del equipo</h2>
    <p class="nota">Parámetros de placa y condiciones ambientales del equipo bajo ensayo.</p>
    <label class="campo"><span>Tipo de equipo</span>
      <select data-dato="equipo">${EQUIPOS.map((e) =>
        `<option value="${e.id}" ${e.id === d.equipo ? "selected" : ""}>${esc(e.nombre)}</option>`).join("")}
      </select></label>
    ${extra}
    <div class="rejilla">
      ${campo("Temp. ambiente (°C)", "tempAmbiente")}
      ${campo("Humedad relativa (%)", "humedad")}
      ${campo("Temp. del devanado (°C)", "tempDevanado")}
    </div>
    <div class="campo"><span>Tipo de aislamiento</span>
      ${opciones("aislamiento", [["aceite", "Sumergido en aceite"], ["seco", "Seco (sólido)"]], solido ? "aceite" : null)}
      ${solido ? `<small>Este equipo es de aislamiento sólido: no lleva aceite.</small>` : ""}
    </div>`;
}

function chips(prueba) {
  const par = (rol, valor) =>
    VACIO.has(valor) ? "" : `<span class="chip ${rol}"><b>${rol[0]}</b> ${esc(valor)}</span>`;
  return par("LINEA", prueba.linea) + par("TIERRA", prueba.tierra) + par("GUARDA", prueba.guarda);
}

function paso2() {
  const lista = pruebasDe(estado.datos);
  pruebaActual();
  return `
    <h2>02. Selección de pruebas</h2>
    <p class="nota">${esc(equipoDe(estado.datos.equipo).nombre)}. Elija la prueba a realizar.</p>
    <div class="pruebas">${lista.map((prueba, i) => `
      <button class="prueba ${i === estado.prueba ? "activo" : ""}" data-prueba="${i}">
        <span class="num">${esc(prueba.prueba)}</span>
        <span class="cuerpo">
          <b>${esc(prueba.medicion)}</b>
          <span class="chips">${chips(prueba)}</span>
          <small>${esc(formatoKv(prueba.kv))} · ${prueba.minutos} min</small>
        </span>
      </button>`).join("")}</div>`;
}

function paso3() {
  const prueba = pruebaActual();
  const medicion = leyendaMedicion(estado.datos, prueba);
  const conexiones = leyendaConexiones(prueba);
  return `
    <h2>03. Diagramas de bloques</h2>
    <p class="nota">Prueba ${esc(prueba.prueba)} · ${esc(prueba.medicion)}</p>
    <div class="segmentos vista">
      <button data-modo="mide" class="${estado.modo === "mide" ? "activo" : ""}">Medición</button>
      <button data-modo="conexiones" class="${estado.modo === "conexiones" ? "activo" : ""}">Conexiones</button>
    </div>
    <div class="diagrama">${dibujarDiagrama(estado.datos, prueba, estado.modo)}</div>
    <h3>Medición</h3>
    <ul class="leyenda">${medicion.map((fila) => `
      <li><span class="badge ${fila.medido ? "medido" : ""}">${fila.codigo}</span>${esc(fila.texto)}</li>`).join("")}</ul>
    <h3>Conexiones</h3>
    <ul class="leyenda">${conexiones.map((fila) => `
      <li><span class="badge ${fila.rol}">${ROTULO[fila.rol]}</span>${esc(fila.texto)}</li>`).join("")}</ul>`;
}

function tarjetaDictamen(res) {
  if (!res) return "";
  if (res.error) return `<div class="aviso">${esc(res.error)}</div>`;
  const indices = [
    res.ia != null ? `<div><small>Índice de absorción (ia)</small><b>${res.ia.toFixed(2)}</b></div>` : "",
    res.ip != null ? `<div><small>Índice de polarización (ip)</small><b>${res.ip.toFixed(2)}</b></div>` : "",
  ].join("");
  return `
    <section class="dictamen ${res.estado}">
      <header>DICTAMEN: ${res.estado}</header>
      ${indices ? `<div class="indices">${indices}</div>` : ""}
      <ul>${res.lineas.map((linea) => `<li>${esc(linea)}</li>`).join("")}</ul>
    </section>
    <div class="acciones">
      <button class="secundario" data-accion="guardar">Guardar en historial</button>
      ${navigator.share ? `<button class="secundario" data-accion="compartir">Compartir</button>` : ""}
    </div>`;
}

function paso4() {
  const prueba = pruebaActual();
  const d = estado.datos;
  const temp = numero(d.tempDevanado);
  const base = baseTemp(d.equipo);
  const kt = temp == null ? null : ktEquipo(temp, d);
  const origen = base === 40 ? "IEEE 43" : `Tabla 1, ${enAceite(d) ? "aceite" : "seco"}`;
  const entrada = (clave, etiqueta) => `
    <label class="campo"><span>${etiqueta}</span>
      <input inputmode="decimal" data-lectura="${clave}" value="${esc(estado.lecturas[clave])}" placeholder="MΩ"></label>`;
  return `
    <h2>04. Captura de lecturas</h2>
    <p class="nota">Prueba ${esc(prueba.prueba)} · ${esc(prueba.medicion)} · ${esc(formatoKv(prueba.kv))}</p>
    <div class="kt">
      <div><small>Factor de corrección a ${base} °C (${origen})</small>
        <b>${kt == null ? "—" : kt.toFixed(3)}</b></div>
      <div><small>Temp. del devanado</small><b>${temp == null ? "—" : `${temp} °C`}</b></div>
    </div>
    ${temp == null ? `<div class="aviso">Falta la temperatura del devanado. Captúrela en el paso 01.</div>` : ""}
    <div class="rejilla">
      ${prueba.minutos === 10 ? entrada("r30", "30 s") : ""}
      ${entrada("r1", "1 min")}
      ${prueba.minutos === 10 ? entrada("r10", "10 min") : ""}
    </div>
    <p class="nota">Sin letra son MΩ. Agregue G para gigaohms o T para teraohms (ej. 2.5G).</p>
    <button class="primario" data-accion="calcular">Calcular dictamen</button>
    <div id="dictamen">${tarjetaDictamen(estado.resultado)}</div>`;
}

function vistaRa() {
  const cuerpo = [paso1, paso2, paso3, paso4][estado.paso - 1]();
  return `
    <header class="barra">
      <button class="atras" data-ir="inicio" aria-label="Volver al menú">‹</button>
      <div><b>Resistencia de Aislamiento</b><small>ST-CT-001</small></div>
    </header>
    ${barraPasos()}
    <main class="contenido">${cuerpo}</main>
    <footer class="pie-pasos">
      <button class="secundario" data-paso="${Math.max(1, estado.paso - 1)}" ${estado.paso === 1 ? "disabled" : ""}>‹ Anterior</button>
      <button class="primario" data-paso="${Math.min(4, estado.paso + 1)}" ${estado.paso === 4 ? "disabled" : ""}>Siguiente ›</button>
    </footer>`;
}

function vistaHistorial() {
  const lista = leer(CLAVE_HISTORIAL, []);
  const filas = lista.length
    ? lista.map((reg) => `
      <li class="registro ${reg.estado}">
        <div><b>${esc(reg.equipo)}</b><span class="badge-estado">${reg.estado}</span></div>
        <small>${esc(reg.fecha)} · Prueba ${esc(reg.prueba)} · ${esc(reg.medicion)}</small>
        <small>${esc(reg.resumen)}</small>
      </li>`).join("")
    : `<li class="vacio">Aún no hay análisis guardados.</li>`;
  return `
    <header class="barra">
      <button class="atras" data-ir="inicio" aria-label="Volver al menú">‹</button>
      <div><b>Historial de Análisis</b><small>${lista.length} registro(s) en este celular</small></div>
    </header>
    <main class="contenido"><ul class="historial">${filas}</ul>
      ${lista.length ? `<button class="secundario" data-accion="borrar-historial">Borrar historial</button>` : ""}
    </main>`;
}

const raiz = document.getElementById("app");

function pintar() {
  raiz.innerHTML = { inicio: vistaInicio, ra: vistaRa, historial: vistaHistorial }[estado.vista]();
  raiz.className = estado.vista;
}

function resumenResultado(res) {
  const partes = [];
  if (res.ip != null) partes.push(`ip ${res.ip.toFixed(2)}`);
  if (res.ia != null) partes.push(`ia ${res.ia.toFixed(2)}`);
  partes.push(`Kt ${res.kt.toFixed(3)} a ${res.base} °C`);
  return partes.join(" · ");
}

function avisar(texto) {
  const aviso = document.createElement("div");
  aviso.className = "toast";
  aviso.textContent = texto;
  document.body.appendChild(aviso);
  setTimeout(() => aviso.remove(), 2200);
}

raiz.addEventListener("click", (evento) => {
  const boton = evento.target.closest("button");
  if (!boton || boton.disabled) return;
  const d = boton.dataset;
  if (d.ir) {
    estado.vista = d.ir;
    if (d.ir === "ra") estado.paso = 1;
  } else if (d.paso) {
    estado.paso = Number(d.paso);
    window.scrollTo(0, 0);
  } else if (d.dato) {
    estado.datos[d.dato] = d.valor;
    estado.resultado = null;
    if (["secciones", "terciario"].includes(d.dato)) estado.prueba = 0;
  } else if (d.prueba) {
    estado.prueba = Number(d.prueba);
    estado.resultado = null;
  } else if (d.modo) {
    estado.modo = d.modo;
  } else if (d.accion === "calcular") {
    estado.resultado = dictamen(estado.datos, pruebaActual(), estado.lecturas);
  } else if (d.accion === "guardar" && estado.resultado && !estado.resultado.error) {
    const prueba = pruebaActual();
    const lista = leer(CLAVE_HISTORIAL, []);
    lista.unshift({
      fecha: new Date().toLocaleString("es-MX", { dateStyle: "short", timeStyle: "short" }),
      equipo: equipoDe(estado.datos.equipo).nombre,
      prueba: prueba.prueba, medicion: prueba.medicion,
      estado: estado.resultado.estado, resumen: resumenResultado(estado.resultado),
    });
    guardar(CLAVE_HISTORIAL, lista.slice(0, 200));
    avisar("Guardado en el historial");
    return;
  } else if (d.accion === "compartir" && estado.resultado) {
    const prueba = pruebaActual();
    navigator.share({
      title: "SAPE — Resistencia de Aislamiento",
      text: [
        `${equipoDe(estado.datos.equipo).nombre} · Prueba ${prueba.prueba} (${prueba.medicion})`,
        `DICTAMEN: ${estado.resultado.estado}`,
        ...estado.resultado.lineas,
      ].join("\n"),
    }).catch(() => {});
    return;
  } else if (d.accion === "borrar-historial") {
    if (!confirm("¿Borrar todo el historial de este celular?")) return;
    guardar(CLAVE_HISTORIAL, []);
  } else {
    return;
  }
  recordar();
  pintar();
});

// Los campos de texto se guardan al escribir, sin repintar (no se pierde el foco).
raiz.addEventListener("input", (evento) => {
  const el = evento.target;
  if (el.dataset.lectura) {
    estado.lecturas[el.dataset.lectura] = el.value;
  } else if (el.dataset.dato && el.tagName === "INPUT") {
    estado.datos[el.dataset.dato] = el.value;
  } else {
    return;
  }
  estado.resultado = null;
  recordar();
});

raiz.addEventListener("change", (evento) => {
  const el = evento.target;
  if (el.tagName !== "SELECT" || !el.dataset.dato) return;
  estado.datos[el.dataset.dato] = el.value;
  estado.prueba = 0;
  estado.resultado = null;
  recordar();
  pintar();
});

pintar();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}
